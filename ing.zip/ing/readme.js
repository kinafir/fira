/// Jangan Di Sebar kan Agar Tidak Di Reset Paktzy
/// Yg Rugi Sapa? Lu Sendiri 